'use client';

import { type InputHTMLAttributes, forwardRef, useState } from 'react';
import { Search, Close } from '../icons';

export interface SearchFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size'> {
  onClear?: () => void;
  className?: string;
}

export const SearchField = forwardRef<HTMLInputElement, SearchFieldProps>(
  function SearchField({ onClear, value, onFocus, onBlur, className = '', ...props }, ref) {
    const hasValue = !!value;
    const [isFocused, setIsFocused] = useState(false);

    // box-shadow instead of border: no layout shift, no content shift on focus.
    // Outset (not inset) so the ring wraps the full component — consistent with TextField.
    const shadowClass = '[box-shadow:0_0_0_1px_var(--color-border-default)] [&:hover:not(:focus-within)]:[box-shadow:0_0_0_2px_var(--color-text-default)] focus-within:[box-shadow:0_0_0_3px_var(--color-text-default)]';

    return (
      <div
        className={`
          flex items-center
          h-[var(--spacing-40)] rounded-[8px] pr-[var(--spacing-4)]
          bg-[var(--color-bg-subtle)]
          [transition:box-shadow_150ms_ease]
          ${shadowClass}
          ${className}
        `}
      >
        <div className="flex items-center justify-center shrink-0 w-[var(--spacing-40)] h-full">
          <Search size={16} color="var(--color-text-tertiary)" />
        </div>

        <input
          ref={ref}
          type="text"
          value={value}
          onFocus={(e) => {
            setIsFocused(true);
            onFocus?.(e);
          }}
          onBlur={(e) => {
            setIsFocused(false);
            onBlur?.(e);
          }}
          className="
            flex-1 min-w-0 h-full bg-transparent outline-none
            text-body-medium
            text-[var(--color-text-default)]
            placeholder:text-[var(--color-text-tertiary)] placeholder:font-normal
          "
          {...props}
        />

        {hasValue && onClear && (
          <button
            type="button"
            onClick={onClear}
            aria-label="Clear search"
            tabIndex={-1}
            className={`
              flex items-center justify-center shrink-0 size-[var(--spacing-32)] rounded-[4px]
              hover:bg-[var(--color-grey-200)]
              active:bg-[var(--color-grey-200)]
              focus-visible:outline-none focus-visible:[box-shadow:0_0_0_3px_var(--color-text-default)]
              transition-colors duration-150
            `}
          >
            <Close
              size={16}
              color={isFocused ? 'var(--color-text-default)' : 'var(--color-text-tertiary)'}
            />
          </button>
        )}
      </div>
    );
  }
);
