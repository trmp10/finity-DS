'use client';

import { useState, useRef, useEffect, useId } from 'react';
import { CaretDown, CaretUp, Check } from '../icons';
import { HelperText } from '../helper-text';
import { FieldLabel } from '../field-label';
import { Checkbox } from '../checkbox';

export type SelectOption = {
  value: string;
  label: string;
  group?: string;
};

export type SelectSize = 'large' | 'medium';

export interface SelectProps {
  label?: string;
  placeholder?: string;
  options: SelectOption[];
  value?: string | string[];
  onChange?: (value: string | string[]) => void;
  size?: SelectSize;
  multiple?: boolean;
  disabled?: boolean;
  readOnly?: boolean;
  errorMessage?: string;
  helperText?: string;
  className?: string;
  id?: string;
}

export function Select({
  label,
  placeholder = 'Select an option',
  options,
  value,
  onChange,
  size = 'large',
  multiple = false,
  disabled = false,
  readOnly = false,
  errorMessage,
  helperText,
  className = '',
  id,
}: SelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const generatedId = useId();
  const triggerId = id ?? generatedId;

  const hasError = !!errorMessage;
  const selectedValues = Array.isArray(value) ? value : value != null ? [value] : [];
  const hasSelection = selectedValues.length > 0;

  const displayText = hasSelection
    ? selectedValues.map(v => options.find(o => o.value === v)?.label ?? v).join(', ')
    : null;

  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [isOpen]);

  const toggleOpen = () => {
    if (disabled || readOnly) return;
    setIsOpen(v => !v);
  };

  const handleSelect = (optionValue: string) => {
    if (!onChange) return;
    if (multiple) {
      const current = Array.isArray(value) ? value : [];
      const next = current.includes(optionValue)
        ? current.filter(v => v !== optionValue)
        : [...current, optionValue];
      onChange(next);
    } else {
      onChange(optionValue);
      setIsOpen(false);
    }
  };

  const triggerH    = size === 'large' ? 'h-[var(--spacing-48)]' : 'h-[var(--spacing-40)]';
  const iconBoxSize = size === 'large' ? 'w-[var(--spacing-48)] h-[var(--spacing-48)]' : 'w-[var(--spacing-40)] h-[var(--spacing-40)]';

  const triggerBg = disabled
    ? 'bg-[var(--color-grey-200)]'
    : readOnly
    ? 'bg-[var(--color-grey-100)]'
    : isOpen
    ? 'bg-[var(--color-base-white)]'
    : 'bg-[var(--color-base-white)] hover:bg-[var(--color-grey-100)]';

  const triggerShadow = hasError
    ? '[box-shadow:0_0_0_2px_var(--color-red-600)]'
    : disabled || readOnly
    ? '[box-shadow:0_0_0_1px_var(--color-border-subtle)]'
    : isOpen
    ? '[box-shadow:0_0_0_3px_var(--color-text-default)]'
    : '[box-shadow:0_0_0_1px_var(--color-border-default)] hover:[box-shadow:0_0_0_1px_var(--color-border-subtle)]';

  const textClass = hasSelection
    ? 'text-body-medium text-[var(--color-text-default)]'
    : disabled
    ? 'text-body-regular text-[var(--color-text-disabled)]'
    : readOnly
    ? 'text-body-medium text-[var(--color-text-secondary)]'
    : 'text-body-regular text-[var(--color-text-tertiary)]';

  const chevronColor = disabled ? 'var(--color-text-disabled)' : 'var(--color-text-default)';

  // Group options
  const grouped = options.some(o => o.group);
  const groups: { name: string | null; items: SelectOption[] }[] = [];
  if (grouped) {
    const map = new Map<string, SelectOption[]>();
    options.forEach(o => {
      const key = o.group ?? '';
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(o);
    });
    map.forEach((items, key) => groups.push({ name: key || null, items }));
  } else {
    groups.push({ name: null, items: options });
  }

  return (
    <div ref={containerRef} className={`relative flex flex-col gap-[var(--spacing-4)] ${className}`}>
      {label && <FieldLabel htmlFor={triggerId}>{label}</FieldLabel>}

      <button
        id={triggerId}
        type="button"
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        onClick={toggleOpen}
        className={[
          'flex items-center w-full overflow-hidden rounded-[8px] outline-none',
          '[transition:box-shadow_150ms_ease,background-color_150ms_ease]',
          triggerH,
          triggerBg,
          triggerShadow,
          disabled ? 'cursor-not-allowed' : readOnly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ')}
      >
        <span className={`flex-1 min-w-0 px-[var(--spacing-12)] text-left truncate ${textClass}`}>
          {displayText ?? placeholder}
        </span>

        {!readOnly && (
          <span className={`flex items-center justify-center shrink-0 ${iconBoxSize}`}>
            {isOpen
              ? <CaretUp size={24} color={chevronColor} />
              : <CaretDown size={24} color={chevronColor} />
            }
          </span>
        )}
      </button>

      {isOpen && (
        <div
          role="listbox"
          aria-multiselectable={multiple}
          className="absolute top-full left-0 right-0 z-50 mt-[var(--spacing-4)] rounded-[8px] border border-[var(--color-grey-200)] overflow-hidden shadow-[0px_4px_6px_rgba(0,0,0,0.1),0px_2px_4px_rgba(0,0,0,0.06)]"
        >
          <div className="bg-[var(--color-base-white)] overflow-y-auto max-h-[200px]">
            {groups.map(({ name, items }, gi) => (
              <div key={gi}>
                {name && (
                  <div className="px-[var(--spacing-16)] pt-[var(--spacing-8)] pb-[var(--spacing-4)] text-compact-semibold text-[var(--color-text-secondary)]">
                    {name}
                  </div>
                )}
                {items.map(option => {
                  const isSelected = selectedValues.includes(option.value);
                  return multiple ? (
                    <div
                      key={option.value}
                      role="option"
                      aria-selected={isSelected}
                      className="hover:bg-[var(--color-grey-100)]"
                    >
                      <Checkbox
                        checked={isSelected}
                        onChange={() => handleSelect(option.value)}
                        label={option.label}
                        className="w-full px-[var(--spacing-16)] py-[var(--spacing-12)]"
                      />
                    </div>
                  ) : (
                    <div
                      key={option.value}
                      role="option"
                      aria-selected={isSelected}
                      onClick={() => handleSelect(option.value)}
                      className="flex items-center cursor-pointer select-none pl-[44px] pr-[var(--spacing-16)] py-[var(--spacing-12)] relative text-body-medium text-[var(--color-text-default)] hover:bg-[var(--color-grey-100)]"
                    >
                      {isSelected && (
                        <span className="absolute left-[var(--spacing-16)] top-1/2 -translate-y-1/2">
                          <Check size={20} color="var(--color-text-default)" />
                        </span>
                      )}
                      <span className="truncate">{option.label}</span>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      )}

      {(helperText || errorMessage) && (
        <HelperText type={hasError ? 'error' : 'default'}>
          {errorMessage || helperText}
        </HelperText>
      )}
    </div>
  );
}
