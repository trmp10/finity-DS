'use client';

import { type ReactNode, useRef, useState, useEffect, useCallback } from 'react';

export interface ScrollbarProps {
  children: ReactNode;
  maxHeight?: number;
  className?: string;
}

export function Scrollbar({ children, maxHeight = 200, className = '' }: ScrollbarProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [thumbHeight, setThumbHeight] = useState(0);
  const [thumbTop, setThumbTop] = useState(4);
  const [hasOverflow, setHasOverflow] = useState(false);

  const updateThumb = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const { scrollTop, scrollHeight, clientHeight } = el;
    const overflow = scrollHeight > clientHeight;
    setHasOverflow(overflow);
    if (!overflow) return;
    const trackH = clientHeight - 8; // 4px padding top + bottom
    const th = Math.max(24, (clientHeight / scrollHeight) * trackH);
    const maxOff = trackH - th;
    const off = (scrollTop / (scrollHeight - clientHeight)) * maxOff;
    setThumbHeight(th);
    setThumbTop(4 + off);
  }, []);

  useEffect(() => {
    updateThumb();
  }, [updateThumb, children]);

  return (
    <div className={`flex overflow-hidden ${className}`} style={{ maxHeight }}>
      <div
        ref={scrollRef}
        onScroll={updateThumb}
        className="flex-1 min-w-0 overflow-y-scroll [&::-webkit-scrollbar]:hidden"
        style={{ scrollbarWidth: 'none' }}
      >
        {children}
      </div>
      {hasOverflow && (
        <div className="relative shrink-0 self-stretch w-[16px]">
          <div
            className="absolute left-[4px] right-[4px] rounded-[8px] bg-[var(--color-grey-300)]"
            style={{ top: thumbTop, height: thumbHeight }}
          />
        </div>
      )}
    </div>
  );
}
