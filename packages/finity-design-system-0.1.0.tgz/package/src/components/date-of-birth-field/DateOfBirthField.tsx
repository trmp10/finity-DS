'use client';

import { useRef } from 'react';
import { HelperText } from '../helper-text';

export interface DateOfBirthValue {
  day: string;
  month: string;
  year: string;
}

export interface DateOfBirthFieldProps {
  label?: string;
  value: DateOfBirthValue;
  onChange: (value: DateOfBirthValue) => void;
  errorMessage?: string;
  helperText?: string;
  disabled?: boolean;
  className?: string;
}

export function DateOfBirthField({
  label = 'Date of birth',
  value,
  onChange,
  errorMessage,
  helperText,
  disabled = false,
  className = '',
}: DateOfBirthFieldProps) {
  const monthRef = useRef<HTMLInputElement>(null);
  const yearRef  = useRef<HTMLInputElement>(null);

  const hasError = !!errorMessage;

  // box-shadow instead of border: no layout shift on hover/focus.
  const slotShadow = hasError
    ? '[box-shadow:0_0_0_2px_var(--color-red-600)] focus-within:[box-shadow:0_0_0_3px_var(--color-red-600)]'
    : disabled
    ? '[box-shadow:0_0_0_1px_var(--color-border-subtle)]'
    : '[box-shadow:0_0_0_1px_var(--color-border-default)] [&:hover:not(:focus-within)]:[box-shadow:0_0_0_2px_var(--color-text-default)] focus-within:[box-shadow:0_0_0_3px_var(--color-text-default)]';

  const bgClass = disabled ? 'bg-[var(--color-grey-100)]' : 'bg-[var(--color-base-white)]';

  const slotClass = [
    'flex items-center overflow-hidden rounded-[8px]',
    'h-[var(--spacing-40)]',
    '[transition:box-shadow_150ms_ease]',
    bgClass,
    slotShadow,
  ].join(' ');

  const inputClass = [
    'w-full h-full bg-transparent outline-none px-[var(--spacing-12)]',
    'text-body-medium text-[var(--color-text-default)]',
    'placeholder:text-[var(--color-text-tertiary)] placeholder:font-normal',
    'disabled:cursor-not-allowed disabled:text-[var(--color-text-disabled)]',
  ].join(' ');

  return (
    <div className={`flex flex-col gap-[var(--spacing-4)] ${className}`}>
      {label && (
        <label className="text-body-medium text-[var(--color-text-secondary)]">
          {label}
        </label>
      )}

      <div className="flex gap-[var(--spacing-8)] items-start">
        {/* Day */}
        <div className={`${slotClass} w-[56px]`}>
          <input
            type="text"
            inputMode="numeric"
            maxLength={2}
            placeholder="DD"
            value={value.day}
            disabled={disabled}
            className={inputClass}
            onChange={(e) => {
              const v = e.target.value.replace(/\D/g, '');
              onChange({ ...value, day: v });
              if (v.length === 2) monthRef.current?.focus();
            }}
          />
        </div>

        {/* Month */}
        <div className={`${slotClass} w-[56px]`}>
          <input
            ref={monthRef}
            type="text"
            inputMode="numeric"
            maxLength={2}
            placeholder="MM"
            value={value.month}
            disabled={disabled}
            className={inputClass}
            onChange={(e) => {
              const v = e.target.value.replace(/\D/g, '');
              onChange({ ...value, month: v });
              if (v.length === 2) yearRef.current?.focus();
            }}
          />
        </div>

        {/* Year */}
        <div className={`${slotClass} w-[66px]`}>
          <input
            ref={yearRef}
            type="text"
            inputMode="numeric"
            maxLength={4}
            placeholder="YYYY"
            value={value.year}
            disabled={disabled}
            className={inputClass}
            onChange={(e) => {
              const v = e.target.value.replace(/\D/g, '');
              onChange({ ...value, year: v });
            }}
          />
        </div>
      </div>

      {(helperText || errorMessage) && (
        <HelperText type={hasError ? 'error' : 'default'}>
          {errorMessage || helperText}
        </HelperText>
      )}
    </div>
  );
}
