'use client';

import { type InputHTMLAttributes, type ReactNode, forwardRef, useId } from 'react';
import { Close } from '../icons';
import { HelperText } from '../helper-text';
import { FieldLabel } from '../field-label';

export type TextFieldSize = 'large' | 'medium';

export interface TextFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size'> {
  label?: string;
  helperText?: string;
  errorMessage?: string;
  prefix?: string;
  suffix?: string;
  suffixIcon?: ReactNode;
  size?: TextFieldSize;
  onClear?: () => void;
}

const heights: Record<TextFieldSize, string> = {
  large: 'h-[var(--spacing-48)]',
  medium: 'h-[var(--spacing-40)]',
};

// Prefix/suffix box is always square — width matches field height
const prefixSuffixWidths: Record<TextFieldSize, string> = {
  large: 'w-[var(--spacing-48)]',
  medium: 'w-[var(--spacing-40)]',
};

export const TextField = forwardRef<HTMLInputElement, TextFieldProps>(function TextField(
  {
    label,
    helperText,
    errorMessage,
    prefix,
    suffix,
    suffixIcon,
    size = 'large',
    onClear,
    disabled = false,
    readOnly = false,
    className = '',
    id,
    value,
    onFocus,
    ...props
  },
  ref
) {
  const generatedId = useId();
  const inputId = id || generatedId;
  const hasError = !!errorMessage;
  // const hasClear = !!onClear && !!value;
  const hasClear = false;
  const hasSuffix = !!suffix || !!suffixIcon;

  // box-shadow instead of border: no layout shift, no content shift on focus.
  // Outset (not inset) so the ring wraps the full component including prefix/suffix.
  const shadowClass = hasError
    ? '[box-shadow:0_0_0_2px_var(--color-red-600)] focus-within:[box-shadow:0_0_0_3px_var(--color-red-600)]'
    : disabled
    ? '[box-shadow:0_0_0_1px_var(--color-border-default)]'
    : readOnly
    ? '[box-shadow:0_0_0_1px_var(--color-border-subtle)]'
    : '[box-shadow:0_0_0_1px_var(--color-border-default)] [&:hover:not(:focus-within)]:[box-shadow:0_0_0_2px_var(--color-text-default)] focus-within:[box-shadow:0_0_0_3px_var(--color-text-default)]';

  const bgClass = disabled
    ? 'bg-[var(--color-grey-200)]'
    : readOnly
    ? 'bg-[var(--color-grey-100)]'
    : 'bg-[var(--color-base-white)]';

  const prefixSuffixBg = disabled
    ? 'bg-[var(--color-grey-200)]'
    : 'bg-[var(--color-grey-100)]';

  const prefixSuffixDivider = disabled
    ? 'border-[var(--color-border-subtle)]'
    : 'border-[var(--color-border-default)]';

  const prefixSuffixText = disabled
    ? 'text-[var(--color-text-disabled)]'
    : 'text-[var(--color-text-secondary)]';

  return (
    <div className={`flex flex-col gap-[var(--spacing-4)] w-full ${className}`}>
      {label && (
        <FieldLabel htmlFor={inputId}>{label}</FieldLabel>
      )}

      <div
        className={`
          flex items-center overflow-hidden rounded-[8px]
          [transition:box-shadow_150ms_ease]
          ${heights[size]}
          ${shadowClass}
          ${bgClass}
        `}
      >
        {prefix && (
          <div
            className={`
              flex items-center justify-center shrink-0 h-full ${prefixSuffixWidths[size]}
              border-r ${prefixSuffixDivider}
              text-body-medium ${prefixSuffixBg} ${prefixSuffixText}
            `}
          >
            {prefix}
          </div>
        )}

        <input
          ref={ref}
          id={inputId}
          value={value}
          disabled={disabled}
          readOnly={readOnly}
          onFocus={(e) => {
            const len = e.target.value.length;
            e.target.setSelectionRange(len, len);
            onFocus?.(e);
          }}
          className={`
            flex-1 min-w-0 h-full bg-transparent outline-none px-[var(--spacing-12)]
            text-body-medium
            text-[var(--color-text-default)]
            placeholder:text-[var(--color-text-tertiary)] placeholder:font-normal
            disabled:cursor-not-allowed disabled:text-[var(--color-text-disabled)]
            read-only:cursor-default
          `}
          {...props}
        />

        {hasClear && (
          <button
            type="button"
            onClick={onClear}
            aria-label="Clear input"
            tabIndex={-1}
            className={`
              flex items-center justify-center shrink-0 h-full
              ${size === 'large' ? 'w-[var(--spacing-48)]' : 'w-[var(--spacing-40)]'}
              text-[var(--color-text-tertiary)] hover:text-[var(--color-text-secondary)]
              transition-colors duration-150
            `}
          >
            <Close size={20} />
          </button>
        )}

        {hasSuffix && (
          <div
            className={`
              flex items-center justify-center shrink-0 h-full ${prefixSuffixWidths[size]}
              border-l ${prefixSuffixDivider}
              text-body-medium ${prefixSuffixBg} ${prefixSuffixText}
            `}
          >
            {suffix || suffixIcon}
          </div>
        )}
      </div>

      {(helperText || errorMessage) && (
        <HelperText type={hasError ? 'error' : 'default'}>
          {errorMessage || helperText}
        </HelperText>
      )}
    </div>
  );
});
