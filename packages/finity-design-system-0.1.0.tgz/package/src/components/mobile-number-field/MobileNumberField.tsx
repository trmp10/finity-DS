'use client';

import { type ChangeEvent, type InputHTMLAttributes, forwardRef, useId } from 'react';
import { FieldLabel } from '../field-label';
import { HelperText } from '../helper-text';

export interface MobileNumberFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size' | 'prefix'> {
  label?: string;
  dialCode?: string;
  helperText?: string;
  errorMessage?: string;
}

// Formats digits as "XXXXX XXXXXX" (space after 5th digit, max 11 digits).
function formatMobileNumber(input: string): string {
  const digits = input.replace(/\D/g, '').slice(0, 11);
  return digits.length > 5 ? `${digits.slice(0, 5)} ${digits.slice(5)}` : digits;
}

export const MobileNumberField = forwardRef<HTMLInputElement, MobileNumberFieldProps>(
  function MobileNumberField(
    {
      label = 'Mobile number',
      dialCode = '+44',
      helperText,
      errorMessage,
      disabled = false,
      className = '',
      id,
      onChange,
      ...props
    },
    ref
  ) {
    const generatedId = useId();
    const inputId = id || generatedId;
    const hasError = !!errorMessage;

    const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
      const formatted = formatMobileNumber(e.target.value);
      e.target.value = formatted;
      onChange?.(e);
    };

    // box-shadow instead of border: no layout shift, no content shift on focus.
    // Outset so the ring wraps the full component — consistent with TextField.
    const shadowClass = hasError
      ? '[box-shadow:0_0_0_2px_var(--color-red-600)] focus-within:[box-shadow:0_0_0_3px_var(--color-red-600)]'
      : disabled
      ? '[box-shadow:0_0_0_1px_var(--color-border-default)]'
      : '[box-shadow:0_0_0_1px_var(--color-border-default)] [&:hover:not(:focus-within)]:[box-shadow:0_0_0_2px_var(--color-text-default)] focus-within:[box-shadow:0_0_0_3px_var(--color-text-default)]';

    const containerBg = disabled ? 'bg-[var(--color-grey-200)]' : 'bg-[var(--color-base-white)]';
    const prefixBg    = disabled ? 'bg-[var(--color-grey-200)]' : 'bg-[var(--color-grey-100)]';
    const prefixDivider = disabled ? 'border-[var(--color-border-subtle)]' : 'border-[var(--color-border-default)]';

    return (
      <div className={`flex flex-col gap-[var(--spacing-4)] w-full ${className}`}>
        {label && (
          <FieldLabel htmlFor={inputId}>{label}</FieldLabel>
        )}

        <div
          className={`
            flex items-center overflow-hidden rounded-[8px]
            h-[var(--spacing-48)]
            [transition:box-shadow_150ms_ease]
            ${shadowClass}
            ${containerBg}
          `}
        >
          <div
            className={`
              flex items-center justify-center shrink-0 h-full px-[var(--spacing-12)]
              border-r ${prefixDivider} ${prefixBg}
            `}
          >
            <span className="text-body-medium text-[var(--color-text-secondary)] w-[var(--spacing-32)] text-center">
              {dialCode}
            </span>
          </div>

          <input
            ref={ref}
            id={inputId}
            type="tel"
            inputMode="numeric"
            disabled={disabled}
            onChange={handleChange}
            className={`
              flex-1 min-w-0 h-full bg-transparent outline-none px-[var(--spacing-12)]
              text-body-medium
              text-[var(--color-text-default)]
              placeholder:text-[var(--color-text-tertiary)] placeholder:font-normal
              disabled:cursor-not-allowed disabled:text-[var(--color-text-disabled)]
            `}
            {...props}
          />
        </div>

        {(helperText || errorMessage) && (
          <HelperText type={hasError ? 'error' : 'default'}>
            {errorMessage || helperText}
          </HelperText>
        )}
      </div>
    );
  }
);
