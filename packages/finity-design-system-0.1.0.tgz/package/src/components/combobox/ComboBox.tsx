'use client';

import React, { useState, useRef, useEffect, useId } from 'react';
import { CaretDown, CaretUp, Check, Close } from '../icons';
import { HelperText } from '../helper-text';
import { FieldLabel } from '../field-label';
import { Scrollbar } from '../scrollbar';

export type ComboBoxOption = {
  value: string;
  label: string;
  group?: string;
};

export type ComboBoxSize = 'large' | 'medium';

export interface ComboBoxProps {
  label?: string;
  placeholder?: string;
  options: ComboBoxOption[];
  value?: string;
  onChange?: (value: string) => void;
  size?: ComboBoxSize;
  disabled?: boolean;
  readOnly?: boolean;
  errorMessage?: string;
  helperText?: string;
  className?: string;
  id?: string;
}

export function ComboBox({
  label,
  placeholder = 'Type here...',
  options,
  value,
  onChange,
  size = 'medium',
  disabled = false,
  readOnly = false,
  errorMessage,
  helperText,
  className = '',
  id,
}: ComboBoxProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const optionRefs = useRef<(HTMLDivElement | null)[]>([]);
  // Always-current value ref — avoids stale closures in event listeners
  const latestValueRef = useRef(value);
  // Prevents caret-triggered focus from overriding isTyping: false
  const caretOpenedRef = useRef(false);
  const generatedId = useId();
  const inputId = id ?? generatedId;

  const hasError = !!errorMessage;

  // Keep latestValueRef current on every render
  latestValueRef.current = value;

  // Sync input display when controlled value changes externally
  useEffect(() => {
    if (value) {
      const found = options.find(o => o.value === value);
      setInputText(found?.label ?? value);
    } else {
      setInputText('');
    }
  }, [value, options]);

  // Reset highlight when dropdown closes
  useEffect(() => {
    if (!isOpen) setHighlightedIndex(-1);
  }, [isOpen]);

  // Scroll highlighted option into view
  useEffect(() => {
    if (highlightedIndex >= 0) {
      optionRefs.current[highlightedIndex]?.scrollIntoView({ block: 'nearest' });
    }
  }, [highlightedIndex]);

  // When opening in show-all mode, scroll to the selected option
  useEffect(() => {
    if (!isOpen || isTyping || !value) return;
    const selectedIndex = options.findIndex(o => o.value === value);
    if (selectedIndex >= 0) {
      setTimeout(() => {
        optionRefs.current[selectedIndex]?.scrollIntoView({ block: 'nearest' });
      }, 0);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  // Close on outside click — uses ref so closure is never stale
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setIsTyping(false);
        const found = latestValueRef.current
          ? options.find(o => o.value === latestValueRef.current)
          : null;
        setInputText(found?.label ?? '');
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [isOpen, options]);

  // Document-level Escape — catches it even when focus is on the caret button
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
        setIsTyping(false);
        setInputText('');
        onChange?.('');
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [isOpen, onChange]);

  const filteredOptions = isTyping && inputText
    ? options.filter(o => o.label.toLowerCase().includes(inputText.toLowerCase()))
    : options;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const next = e.target.value;
    setInputText(next);
    setIsTyping(true);
    setIsOpen(true);
    setHighlightedIndex(-1);
    if (next === '') onChange?.('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        if (!isOpen) {
          setIsOpen(true);
          setHighlightedIndex(0);
        } else {
          setHighlightedIndex(i => (i < filteredOptions.length - 1 ? i + 1 : i));
        }
        break;
      case 'ArrowUp':
        e.preventDefault();
        if (isOpen) {
          setHighlightedIndex(i => (i > 0 ? i - 1 : 0));
        }
        break;
      case 'Enter':
        e.preventDefault();
        if (isOpen && highlightedIndex >= 0 && filteredOptions[highlightedIndex]) {
          handleSelect(filteredOptions[highlightedIndex]);
        }
        break;
    }
  };

  const handleInputFocus = () => {
    if (!disabled && !readOnly) {
      if (caretOpenedRef.current) {
        caretOpenedRef.current = false;
      } else {
        setIsTyping(true);
      }
      setIsOpen(true);
    }
  };

  const handleSelect = (option: ComboBoxOption) => {
    setInputText(option.label);
    setIsTyping(false);
    setIsOpen(false);
    onChange?.(option.value);
  };

  const handleCaretClick = () => {
    if (disabled || readOnly) return;
    const next = !isOpen;
    setIsTyping(false);
    setIsOpen(next);
    if (next) {
      caretOpenedRef.current = true;
      inputRef.current?.focus();
    }
  };

  const heights: Record<ComboBoxSize, string> = {
    large:  'h-[var(--spacing-48)]',
    medium: 'h-[var(--spacing-40)]',
  };
  const buttonWidths: Record<ComboBoxSize, string> = {
    large:  'w-[var(--spacing-48)]',
    medium: 'w-[var(--spacing-40)]',
  };

  const wrapperBg = disabled
    ? 'bg-[var(--color-grey-200)]'
    : readOnly
    ? 'bg-[var(--color-grey-100)]'
    : 'bg-[var(--color-base-white)]';

  const shadowClass = hasError
    ? '[box-shadow:0_0_0_2px_var(--color-red-600)] focus-within:[box-shadow:0_0_0_3px_var(--color-red-600)]'
    : disabled
    ? '[box-shadow:0_0_0_1px_var(--color-border-default)]'
    : readOnly
    ? '[box-shadow:0_0_0_1px_var(--color-border-subtle)]'
    : '[box-shadow:0_0_0_1px_var(--color-border-default)] [&:hover:not(:focus-within)]:[box-shadow:0_0_0_2px_var(--color-text-default)] focus-within:[box-shadow:0_0_0_3px_var(--color-text-default)]';

  const buttonBorderColor = disabled
    ? 'border-[var(--color-border-subtle)]'
    : 'border-[var(--color-border-default)]';

  const buttonBg = disabled
    ? 'bg-[var(--color-grey-200)]'
    : 'bg-[var(--color-base-white)]';

  const hasValue = value != null && value !== '';
  const chevronColor = disabled ? 'var(--color-text-disabled)' : 'var(--color-text-default)';

  return (
    <div ref={containerRef} className={`relative flex flex-col gap-[var(--spacing-4)] ${className}`}>
      {label && <FieldLabel htmlFor={inputId}>{label}</FieldLabel>}

      <div
        className={[
          'flex items-center overflow-hidden rounded-[8px]',
          '[transition:box-shadow_150ms_ease]',
          heights[size],
          wrapperBg,
          shadowClass,
        ].join(' ')}
      >
        <input
          ref={inputRef}
          id={inputId}
          type="text"
          value={inputText}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={handleInputFocus}
          placeholder={placeholder}
          disabled={disabled}
          readOnly={readOnly}
          aria-autocomplete="list"
          aria-expanded={isOpen}
          aria-haspopup="listbox"
          aria-activedescendant={
            highlightedIndex >= 0 ? `${inputId}-option-${highlightedIndex}` : undefined
          }
          className={[
            'flex-1 min-w-0 h-full bg-transparent outline-none px-[var(--spacing-12)]',
            hasValue
              ? 'text-body-medium text-[var(--color-text-default)]'
              : 'text-body-medium text-[var(--color-text-default)] placeholder:text-[var(--color-text-tertiary)] placeholder:font-normal',
            disabled ? 'cursor-not-allowed text-[var(--color-text-disabled)] placeholder:text-[var(--color-text-disabled)]' : '',
            readOnly ? 'cursor-default' : '',
          ].filter(Boolean).join(' ')}
        />

        {false && hasValue && !disabled && !readOnly && (
          <button
            type="button"
            tabIndex={-1}
            onClick={() => {
              setInputText('');
              onChange?.('');
              setIsOpen(false);
              inputRef.current?.focus();
            }}
            aria-label="Clear selection"
            className={[
              'flex items-center justify-center shrink-0 h-full',
              size === 'large' ? 'w-[var(--spacing-48)]' : 'w-[var(--spacing-40)]',
              'text-[var(--color-text-tertiary)] hover:text-[var(--color-text-secondary)]',
              'transition-colors duration-150',
            ].join(' ')}
          >
            <Close size={20} />
          </button>
        )}

        {!readOnly && (
          <button
            type="button"
            tabIndex={-1}
            onClick={handleCaretClick}
            disabled={disabled}
            className={[
              'flex items-center justify-center shrink-0 h-full outline-none',
              'border-l',
              buttonBorderColor,
              buttonBg,
              buttonWidths[size],
              disabled ? 'cursor-not-allowed' : 'cursor-pointer',
            ].join(' ')}
          >
            {isOpen
              ? <CaretUp size={24} color={chevronColor} />
              : <CaretDown size={24} color={chevronColor} />
            }
          </button>
        )}
      </div>

      {isOpen && !disabled && !readOnly && (
        <div
          role="listbox"
          className="absolute top-full left-0 right-0 z-50 mt-[var(--spacing-4)] rounded-[8px] border border-[var(--color-grey-200)] overflow-hidden shadow-[0px_4px_6px_rgba(0,0,0,0.1),0px_2px_4px_rgba(0,0,0,0.06)]"
        >
          <Scrollbar maxHeight={240} className="bg-[var(--color-base-white)] rounded-[8px]">
            {filteredOptions.length === 0 ? (
              <div className="px-[var(--spacing-12)] py-[var(--spacing-12)] text-body-medium text-[var(--color-text-tertiary)]">
                No results
              </div>
            ) : (
              filteredOptions.map((option, index) => {
                const isSelected    = option.value === value;
                const isHighlighted = index === highlightedIndex;
                return (
                  <div
                    key={option.value}
                    id={`${inputId}-option-${index}`}
                    ref={el => { optionRefs.current[index] = el; }}
                    role="option"
                    aria-selected={isSelected}
                    onMouseDown={e => {
                      e.preventDefault();
                      handleSelect(option);
                    }}
                    onMouseEnter={() => setHighlightedIndex(index)}
                    className={[
                      'flex items-center gap-[var(--spacing-8)] cursor-pointer select-none',
                      'pl-[var(--spacing-12)] pr-[var(--spacing-12)] py-[var(--spacing-12)]',
                      'text-body-medium text-[var(--color-text-default)]',
                      '[transition:background-color_150ms_ease]',
                      isSelected || isHighlighted
                        ? 'bg-[var(--color-grey-100)]'
                        : 'hover:bg-[var(--color-grey-100)]',
                    ].join(' ')}
                  >
                    <span className="shrink-0 w-[20px] h-[20px] flex items-center justify-center">
                      {isSelected && <Check size={20} color="var(--color-text-default)" />}
                    </span>
                    <span className="flex-1 min-w-0 truncate">{option.label}</span>
                  </div>
                );
              })
            )}
          </Scrollbar>
        </div>
      )}

      {(helperText || errorMessage) && (
        <HelperText type={hasError ? 'error' : 'default'}>
          {errorMessage || helperText}
        </HelperText>
      )}
    </div>
  );
}
