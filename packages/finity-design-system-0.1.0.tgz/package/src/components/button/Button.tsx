'use client';

import { type ButtonHTMLAttributes, type ReactNode } from 'react';

export type ButtonVariant = 'primary' | 'secondary' | 'tertiary' | 'emphasis' | 'danger';
export type ButtonSize = 'large' | 'medium' | 'small';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  iconLeft?: ReactNode;
  iconRight?: ReactNode;
  iconOnly?: boolean;
  loading?: boolean;
  children?: ReactNode;
}

const sizeStyles: Record<ButtonSize, string> = {
  large: 'h-[var(--spacing-48)] px-[var(--spacing-16)] text-base gap-[var(--spacing-4)]',
  medium: 'h-[var(--spacing-40)] px-[var(--spacing-16)] text-base gap-[var(--spacing-4)]',
  small: 'h-[var(--spacing-32)] px-[var(--spacing-12)] text-sm gap-[var(--spacing-4)]',
};

const iconOnlySizeStyles: Record<ButtonSize, string> = {
  large: 'h-[var(--spacing-48)] w-[var(--spacing-48)]',
  medium: 'h-[var(--spacing-40)] w-[var(--spacing-40)]',
  small: 'h-[var(--spacing-32)] w-[var(--spacing-32)]',
};

const variantStyles: Record<ButtonVariant, string> = {
  primary: `
    bg-[var(--color-grey-800)] text-[var(--color-base-white)]
    hover:bg-[var(--color-base-black)]
    active:bg-[var(--color-base-black)]
    focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[var(--color-grey-900)]
  `,
  secondary: `
    bg-[var(--color-grey-100)] text-[var(--color-grey-700)]
    hover:bg-[var(--color-grey-200)]
    active:bg-[var(--color-grey-200)]
    focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[var(--color-grey-900)]
  `,
  tertiary: `
    bg-transparent text-[var(--color-grey-900)]
    hover:bg-[var(--color-grey-100)]
    active:bg-[var(--color-grey-200)]
    focus-visible:ring-2 focus-visible:ring-[var(--color-grey-400)] focus-visible:ring-offset-2
  `,
  emphasis: `
    bg-[var(--color-coral-400)] text-[var(--color-base-white)]
    hover:bg-[var(--color-coral-500)]
    active:bg-[var(--color-coral-600)]
    focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[var(--color-coral-400)]
  `,
  danger: `
    bg-[var(--color-red-500)] text-[var(--color-base-white)]
    hover:bg-[var(--color-red-600)]
    active:bg-[var(--color-red-700)]
    focus-visible:ring-2 focus-visible:ring-[var(--color-red-500)] focus-visible:ring-offset-2
  `,
};

const disabledStyles = `
  bg-[var(--color-grey-200)] text-[var(--color-grey-400)]
  cursor-not-allowed border-transparent
`;

const loadingStyles = `
  bg-[var(--color-grey-400)] text-[var(--color-base-white)]
  cursor-wait border-transparent
`;

function LoadingSpinner() {
  return (
    <svg
      className="animate-spin"
      width={20}
      height={20}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeOpacity="0.3"
      />
      <path
        fill="currentColor"
        d="M12 2a10 10 0 0 1 10 10h-2.5A7.5 7.5 0 0 0 12 4.5V2z"
      />
    </svg>
  );
}

export function Button({
  variant = 'primary',
  size = 'medium',
  iconLeft,
  iconRight,
  iconOnly = false,
  loading = false,
  disabled = false,
  children,
  className = '',
  ...props
}: ButtonProps) {
  const isDisabled = disabled || loading;

  const baseStyles = `
    inline-flex items-center justify-center
    font-medium rounded-full
    transition-colors duration-150
    focus:outline-none
    whitespace-nowrap
  `;

  const sizeStyle = iconOnly ? iconOnlySizeStyles[size] : sizeStyles[size];
  const variantStyle = disabled ? disabledStyles : loading ? loadingStyles : variantStyles[variant];

  return (
    <button
      className={`${baseStyles} ${sizeStyle} ${variantStyle} ${className}`.replace(/\s+/g, ' ').trim()}
      disabled={isDisabled}
      {...props}
    >
      {loading ? (
        <span className="relative inline-flex items-center justify-center">
          <span className="invisible inline-flex items-center gap-[var(--spacing-4)]">
            {iconLeft && <span className="flex-shrink-0">{iconLeft}</span>}
            {children && <span>{children}</span>}
            {iconRight && <span className="flex-shrink-0">{iconRight}</span>}
          </span>
          <span className="absolute"><LoadingSpinner /></span>
        </span>
      ) : (
        <>
          {iconLeft && <span className="flex-shrink-0">{iconLeft}</span>}
          {iconOnly ? (
            <span className="flex-shrink-0">{children}</span>
          ) : (
            children && <span>{children}</span>
          )}
          {iconRight && <span className="flex-shrink-0">{iconRight}</span>}
        </>
      )}
    </button>
  );
}
