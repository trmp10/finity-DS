'use client';

import { type ButtonHTMLAttributes, type ReactNode } from 'react';

export type ButtonVariant = 'primary' | 'secondary' | 'tertiary' | 'emphasis' | 'danger';
export type ButtonSize = 'large' | 'medium' | 'small';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  iconLeft?: ReactNode;
  iconRight?: ReactNode;
  iconOnly?: boolean;
  loading?: boolean;
  children?: ReactNode;
}

const sizeStyles: Record<ButtonSize, string> = {
  large:  'h-[var(--spacing-48)] px-[var(--spacing-16)] text-base gap-[var(--spacing-8)]',
  medium: 'h-[var(--spacing-40)] px-[var(--spacing-16)] text-base gap-[var(--spacing-8)]',
  small:  'h-[var(--spacing-32)] px-[var(--spacing-12)] text-sm  gap-[var(--spacing-4)]',
};

const iconOnlySizeStyles: Record<ButtonSize, string> = {
  large:  'h-[var(--spacing-48)] w-[var(--spacing-48)]',
  medium: 'h-[var(--spacing-40)] w-[var(--spacing-40)]',
  small:  'h-[var(--spacing-32)] w-[var(--spacing-32)]',
};

const focusRing = 'focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[var(--color-grey-900)] focus-visible:outline-offset-[2px]';

const variantStyles: Record<ButtonVariant, string> = {
  primary: `
    cursor-pointer
    bg-[var(--color-grey-800)] text-[var(--color-base-white)]
    hover:bg-[var(--color-base-black)]
    active:bg-[var(--color-grey-800)]
    ${focusRing}
  `,
  secondary: `
    cursor-pointer
    bg-[var(--color-base-white)] border border-[var(--color-grey-400)] text-[var(--color-text-default)]
    hover:bg-[var(--color-grey-100)]
    active:bg-[var(--color-grey-200)]
    ${focusRing}
  `,
  tertiary: `
    cursor-pointer
    bg-transparent text-[var(--color-grey-900)]
    hover:bg-[var(--color-grey-100)]
    active:bg-[var(--color-grey-200)]
    ${focusRing}
  `,
  emphasis: `
    cursor-pointer
    bg-[var(--color-coral-400)] text-[var(--color-base-white)]
    hover:bg-[var(--color-coral-500)]
    active:bg-[var(--color-coral-600)]
    ${focusRing}
  `,
  danger: `
    cursor-pointer
    bg-[var(--color-red-500)] text-[var(--color-base-white)]
    hover:bg-[var(--color-red-600)]
    active:bg-[var(--color-red-700)]
    ${focusRing}
  `,
};

const disabledStyles = `
  bg-[var(--color-grey-200)] text-[var(--color-grey-400)]
  cursor-not-allowed border-transparent
`;

const loadingVariantStyles: Record<ButtonVariant, string> = {
  primary:  `cursor-not-allowed bg-[var(--color-grey-400)] text-[var(--color-base-white)] ${focusRing}`,
  secondary: `cursor-not-allowed bg-[var(--color-base-white)] border border-[var(--color-grey-400)] text-[var(--color-grey-900)] ${focusRing}`,
  tertiary:  `cursor-not-allowed bg-transparent text-[var(--color-grey-900)] ${focusRing}`,
  emphasis:  `cursor-not-allowed bg-[var(--color-coral-300)] text-[var(--color-base-white)] ${focusRing}`,
  danger:    `cursor-not-allowed bg-[var(--color-red-400)] text-[var(--color-base-white)] ${focusRing}`,
};

function LoadingSpinner() {
  return (
    <svg
      className="animate-spin"
      width={20}
      height={20}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill="currentColor"
        d="M12 2a10 10 0 0 1 10 10h-2.5A7.5 7.5 0 0 0 12 4.5V2z"
      />
    </svg>
  );
}

export function Button({
  variant = 'primary',
  size = 'medium',
  iconLeft,
  iconRight,
  iconOnly = false,
  loading = false,
  disabled = false,
  children,
  className = '',
  onClick,
  ...props
}: ButtonProps) {
  const isDisabled = disabled;

  const baseStyles = `
    inline-flex items-center justify-center overflow-hidden
    font-medium tracking-[0.35px] leading-[22px] rounded-full
    transition-colors duration-150
    whitespace-nowrap
  `;

  const sizeStyle = iconOnly ? iconOnlySizeStyles[size] : sizeStyles[size];
  const variantStyle = disabled ? disabledStyles : loading ? loadingVariantStyles[variant] : variantStyles[variant];

  return (
    <button
      className={`${baseStyles} ${sizeStyle} ${variantStyle} ${className}`.replace(/\s+/g, ' ').trim()}
      disabled={isDisabled}
      aria-busy={loading}
      onClick={loading ? undefined : onClick}
      {...props}
    >
      {loading ? (
        <span className="relative inline-flex items-center justify-center h-[24px] px-[4px]">
          <span className="invisible inline-flex items-center gap-[var(--spacing-8)]">
            {iconLeft && <span className="flex-shrink-0">{iconLeft}</span>}
            {!iconOnly && children && <span>{children}</span>}
            {iconRight && <span className="flex-shrink-0">{iconRight}</span>}
          </span>
          <span className="absolute"><LoadingSpinner /></span>
        </span>
      ) : iconOnly ? (
        <span className="flex-shrink-0">{children}</span>
      ) : (
        <span className="inline-flex items-center justify-center h-[24px] px-[4px] shrink-0" style={{ gap: 'inherit' }}>
          {iconLeft && <span className="flex-shrink-0">{iconLeft}</span>}
          {children && <span>{children}</span>}
          {iconRight && <span className="flex-shrink-0">{iconRight}</span>}
        </span>
      )}
    </button>
  );
}
