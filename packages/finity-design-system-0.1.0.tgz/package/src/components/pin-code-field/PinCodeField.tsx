'use client';

import { type ChangeEvent, type ClipboardEvent, type KeyboardEvent, useRef } from 'react';
import { HelperText } from '../helper-text';

export type PinCodeSize = 'large' | 'medium';

export interface PinCodeFieldProps {
  length?: 4 | 6;
  size?: PinCodeSize;
  value: string;
  onChange: (value: string) => void;
  errorMessage?: string;
  helperText?: string;
  disabled?: boolean;
  readOnly?: boolean;
  className?: string;
}

export function PinCodeField({
  length = 6,
  size = 'large',
  value,
  onChange,
  errorMessage,
  helperText,
  disabled = false,
  readOnly = false,
  className = '',
}: PinCodeFieldProps) {
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const hasError = !!errorMessage;
  const digits = Array.from({ length }, (_, i) => value[i] || '');

  const slotDimension = size === 'large' ? 'w-[56px] h-[56px]' : 'w-[48px] h-[48px]';
  const slotBg = (disabled || readOnly) ? 'bg-[var(--color-grey-100)]' : 'bg-[var(--color-base-white)]';

  // box-shadow instead of border: no layout shift, no content shift on focus.
  const shadowClass = hasError
    ? '[box-shadow:0_0_0_2px_var(--color-red-600)]'
    : (disabled || readOnly)
    ? '[box-shadow:0_0_0_1px_var(--color-border-subtle)]'
    : '[box-shadow:0_0_0_1px_var(--color-border-default)] [&:hover:not(:focus)]:[box-shadow:0_0_0_2px_var(--color-text-default)] focus:[box-shadow:0_0_0_3px_var(--color-text-default)]';

  const slotClass = `
    ${slotDimension} rounded-[8px] outline-none text-center
    font-semibold text-size-heading-md
    text-[var(--color-text-default)]
    [transition:box-shadow_150ms_ease]
    ${shadowClass} ${slotBg}
    ${disabled || readOnly ? 'cursor-not-allowed' : ''}
  `;

  const handleChange = (index: number, e: ChangeEvent<HTMLInputElement>) => {
    const char = e.target.value.replace(/\D/g, '').slice(-1);
    const newDigits = [...digits];
    newDigits[index] = char;
    onChange(newDigits.join(''));
    if (char && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[index] && index > 0) {
      const newDigits = [...digits];
      newDigits[index - 1] = '';
      onChange(newDigits.join(''));
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, length);
    onChange(pasted);
    const focusIndex = Math.min(pasted.length, length - 1);
    inputRefs.current[focusIndex]?.focus();
  };

  const slots = digits.map((digit, i) => (
    <input
      key={i}
      ref={(el) => { inputRefs.current[i] = el; }}
      type="text"
      inputMode="numeric"
      maxLength={1}
      value={digit}
      disabled={disabled}
      readOnly={readOnly}
      className={slotClass}
      onChange={(e) => handleChange(i, e)}
      onKeyDown={(e) => handleKeyDown(i, e)}
      onPaste={handlePaste}
    />
  ));

  const slotsWithDivider = length === 6
    ? [
        ...slots.slice(0, 3),
        <div
          key="divider"
          className="w-[8px] h-0 border-t border-[var(--color-border-default)] self-center"
        />,
        ...slots.slice(3),
      ]
    : slots;

  return (
    <div className={`flex flex-col gap-[var(--spacing-4)] items-start ${className}`}>
      <div className="flex items-center gap-[var(--spacing-8)]">
        {slotsWithDivider}
      </div>

      {(helperText || errorMessage) && (
        <HelperText type={hasError ? 'error' : 'default'}>
          {errorMessage || helperText}
        </HelperText>
      )}
    </div>
  );
}
