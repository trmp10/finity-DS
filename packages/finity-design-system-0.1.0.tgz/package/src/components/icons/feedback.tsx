import { type IconProps, defaultIconProps } from './Icon';

export const InfoFilled = ({
  size = defaultIconProps.size,
  color = 'var(--color-grey-600)',
  ...props
}: IconProps) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 15 15"
    fill="none"
    {...props}
  >
    <path d="M14.6667 7.33333C14.6667 11.3834 11.3834 14.6667 7.33333 14.6667C3.28324 14.6667 0 11.3834 0 7.33333C0 3.28324 3.28324 0 7.33333 0C11.3834 0 14.6667 3.28324 14.6667 7.33333Z" fill={color} />
    <path fillRule="evenodd" clipRule="evenodd" d="M7.33333 12.3333C6.78105 12.3333 6.33333 11.8856 6.33333 11.3333L6.33333 7.33333C6.33333 6.78105 6.78105 6.33333 7.33333 6.33333C7.88562 6.33333 8.33333 6.78105 8.33333 7.33333V11.3333C8.33333 11.8856 7.88562 12.3333 7.33333 12.3333Z" fill="white" />
    <path d="M6 4C6 3.26362 6.59695 2.66667 7.33333 2.66667C8.06971 2.66667 8.66667 3.26362 8.66667 4C8.66667 4.73638 8.06971 5.33333 7.33333 5.33333C6.59695 5.33333 6 4.73638 6 4Z" fill="white" />
  </svg>
);
InfoFilled.displayName = 'InfoFilled';

export const ErrorFilled = ({
  size = defaultIconProps.size,
  color = 'var(--color-red-600)',
  ...props
}: IconProps) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 15 15"
    fill="none"
    {...props}
  >
    <path fillRule="evenodd" clipRule="evenodd" d="M7.33333 0C11.3834 0 14.6667 3.28325 14.6667 7.33333C14.6667 11.3834 11.3834 14.6667 7.33333 14.6667C3.28325 14.6667 0 11.3834 0 7.33333C0 3.28325 3.28325 0 7.33333 0ZM7.33333 9.33333C6.59695 9.33333 6 9.93029 6 10.6667C6 11.403 6.59695 12 7.33333 12C8.06971 12 8.66667 11.403 8.66667 10.6667C8.66667 9.93029 8.06971 9.33333 7.33333 9.33333ZM7.33333 2.33333C6.78105 2.33333 6.33333 2.78105 6.33333 3.33333V7.33333C6.33333 7.88562 6.78105 8.33333 7.33333 8.33333C7.88562 8.33333 8.33333 7.88562 8.33333 7.33333V3.33333C8.33333 2.78105 7.88562 2.33333 7.33333 2.33333Z" fill={color} />
  </svg>
);
ErrorFilled.displayName = 'ErrorFilled';

export const SuccessFilled = ({
  size = defaultIconProps.size,
  color = 'var(--color-green-600)',
  ...props
}: IconProps) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 15 15"
    fill="none"
    {...props}
  >
    <path fillRule="evenodd" clipRule="evenodd" d="M7.33333 14.6667C11.3834 14.6667 14.6667 11.3834 14.6667 7.33333C14.6667 3.28325 11.3834 0 7.33333 0C3.28325 0 0 3.28325 0 7.33333C0 11.3834 3.28325 14.6667 7.33333 14.6667ZM11.3738 5.90698C11.7643 5.51645 11.7643 4.88329 11.3738 4.49276C10.9832 4.10224 10.3501 4.10224 9.95956 4.49276L5.88114 8.57118L4.64806 7.02983C4.30305 6.59856 3.67375 6.52864 3.24249 6.87365C2.81123 7.21866 2.74131 7.84795 3.08632 8.27922L5.01735 10.693C5.19504 10.9151 5.45891 11.0511 5.74292 11.0668C6.02693 11.0825 6.3042 10.9766 6.50533 10.7754L11.3738 5.90698Z" fill={color} />
  </svg>
);
SuccessFilled.displayName = 'SuccessFilled';

export const WarningFilled = ({
  size = defaultIconProps.size,
  color = 'var(--color-yellow-600)',
  ...props
}: IconProps) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 15 13"
    fill="none"
    {...props}
  >
    <path d="M6.60404 0.334352C6.86037 -0.111451 7.50357 -0.11145 7.75991 0.334353L14.2742 11.6636C14.5298 12.108 14.209 12.6626 13.6963 12.6626H0.667657C0.15498 12.6626 -0.165835 12.108 0.08972 11.6636L6.60404 0.334352Z" fill={color} />
    <path fillRule="evenodd" clipRule="evenodd" d="M7.18197 3.32924C7.73426 3.32924 8.18197 3.77696 8.18197 4.32924V6.66258C8.18197 7.21486 7.73426 7.66258 7.18197 7.66258C6.62969 7.66258 6.18197 7.21486 6.18197 6.66258V4.32924C6.18197 3.77696 6.62969 3.32924 7.18197 3.32924Z" fill="white" />
    <path d="M8.51531 9.99591C8.51531 10.7323 7.91835 11.3292 7.18197 11.3292C6.44559 11.3292 5.84864 10.7323 5.84864 9.99591C5.84864 9.25953 6.44559 8.66258 7.18197 8.66258C7.91835 8.66258 8.51531 9.25953 8.51531 9.99591Z" fill="white" />
  </svg>
);
WarningFilled.displayName = 'WarningFilled';

export const CloseFilled = ({
  size = defaultIconProps.size,
  color = 'var(--color-grey-500)',
  ...props
}: IconProps) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill={color}
    {...props}
  >
    <path d="M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z" />
  </svg>
);
CloseFilled.displayName = 'CloseFilled';
