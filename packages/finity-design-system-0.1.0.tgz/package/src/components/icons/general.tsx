import { createIcon } from './Icon';

// A
export const Add = createIcon(
  <path d="M12 5v14M5 12h14" />,
  'Add'
);

export const AddSquare = createIcon(
  <>
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <path d="M12 8v8M8 12h8" />
  </>,
  'AddSquare'
);

// B
export const Bank = createIcon(
  <path d="M3 21h18M3 10h18M5 6l7-3 7 3M4 10v11M20 10v11M8 14v3M12 14v3M16 14v3" />,
  'Bank'
);

export const Book = createIcon(
  <>
    <path d="M4 19.5A2.5 2.5 0 016.5 17H20" />
    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" />
  </>,
  'Book'
);

export const Building = createIcon(
  <>
    <path d="M6 22V4a2 2 0 012-2h8a2 2 0 012 2v18z" />
    <path d="M6 12H4a2 2 0 00-2 2v8a2 2 0 002 2h2" />
    <path d="M18 9h2a2 2 0 012 2v9a2 2 0 01-2 2h-2" />
    <path d="M10 6h4M10 10h4M10 14h4M10 18h4" />
  </>,
  'Building'
);

// C
export const Calculator = createIcon(
  <>
    <rect x="4" y="2" width="16" height="20" rx="2" />
    <path d="M8 6h8" />
    <path d="M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01M8 18h.01M16 18h.01" />
  </>,
  'Calculator'
);

export const Calendar = createIcon(
  <>
    <rect x="3" y="4" width="18" height="18" rx="2" />
    <path d="M16 2v4M8 2v4M3 10h18" />
  </>,
  'Calendar'
);

export const CalendarCheck = createIcon(
  <>
    <rect x="3" y="4" width="18" height="18" rx="2" />
    <path d="M16 2v4M8 2v4M3 10h18" />
    <path d="M9 16l2 2 4-4" />
  </>,
  'CalendarCheck'
);

export const Camera = createIcon(
  <>
    <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z" />
    <circle cx="12" cy="13" r="4" />
  </>,
  'Camera'
);

export const Card = createIcon(
  <>
    <rect x="2" y="5" width="20" height="14" rx="2" />
    <line x1="2" y1="10" x2="22" y2="10" />
  </>,
  'Card'
);

export const CardCheck = createIcon(
  <>
    <rect x="2" y="5" width="20" height="14" rx="2" />
    <line x1="2" y1="10" x2="22" y2="10" />
    <path d="M9 15l1.5 1.5L14 13" />
  </>,
  'CardCheck'
);

export const CardDetails = createIcon(
  <>
    <rect x="2" y="5" width="20" height="14" rx="2" />
    <line x1="2" y1="10" x2="22" y2="10" />
    <path d="M6 15h2M14 15h4" />
  </>,
  'CardDetails'
);

export const CardFilled = createIcon(
  <>
    <rect x="2" y="5" width="20" height="14" rx="2" fill="currentColor" stroke="none" />
    <line x1="2" y1="10" x2="22" y2="10" stroke="white" strokeWidth={4} />
  </>,
  'CardFilled'
);

export const Chart = createIcon(
  <>
    <rect x="18" y="3" width="4" height="18" rx="1" />
    <rect x="10" y="8" width="4" height="13" rx="1" />
    <rect x="2" y="13" width="4" height="8" rx="1" />
  </>,
  'Chart'
);

export const Chart2 = createIcon(
  <>
    <path d="M3 3v18h18" />
    <path d="M7 15l4-4 4 4 5-5" />
  </>,
  'Chart2'
);

export const Chat = createIcon(
  <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" />,
  'Chat'
);

export const Check = createIcon(
  <path d="M20 6L9 17l-5-5" />,
  'Check'
);

export const CheckCircle = createIcon(
  <>
    <circle cx="12" cy="12" r="10" />
    <path d="M9 12l2 2 4-4" />
  </>,
  'CheckCircle'
);

export const CheckSquare = createIcon(
  <>
    <polyline points="9 11 12 14 22 4" />
    <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" />
  </>,
  'CheckSquare'
);

export const Checklist = createIcon(
  <>
    <line x1="10" y1="6" x2="21" y2="6" />
    <line x1="10" y1="12" x2="21" y2="12" />
    <line x1="10" y1="18" x2="21" y2="18" />
    <polyline points="3 6 4 7 6 5" />
    <polyline points="3 12 4 13 6 11" />
    <polyline points="3 18 4 19 6 17" />
  </>,
  'Checklist'
);

export const Clock = createIcon(
  <>
    <circle cx="12" cy="12" r="10" />
    <path d="M12 6v6l4 2" />
  </>,
  'Clock'
);

export const ClockAdd = createIcon(
  <>
    <path d="M12 22a10 10 0 01-10-10A10 10 0 0112 2c5.52 0 10 4.48 10 10" />
    <path d="M12 6v6l3 3" />
    <path d="M18 21v-6M15 18h6" />
  </>,
  'ClockAdd'
);

export const ClockBackward = createIcon(
  <>
    <path d="M3 7v6h6" />
    <path d="M21 17a9 9 0 00-9-9 9 9 0 00-6 2.3L3 13" />
    <path d="M12 7v5l3 3" />
  </>,
  'ClockBackward'
);

export const ClockFilled = createIcon(
  <>
    <circle cx="12" cy="12" r="10" fill="currentColor" stroke="none" />
    <path d="M12 6v6l4 2" stroke="white" />
  </>,
  'ClockFilled'
);

export const Close = createIcon(
  <path d="M18 6L6 18M6 6l12 12" />,
  'Close'
);

export const Coins = createIcon(
  <>
    <circle cx="8" cy="14" r="6" />
    <circle cx="16" cy="10" r="6" />
  </>,
  'Coins'
);

export const Collapse = createIcon(
  <>
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <path d="M9 3v18M15 9l-3 3 3 3" />
  </>,
  'Collapse'
);

export const ColumnHorizontal = createIcon(
  <>
    <rect x="2" y="3" width="20" height="18" rx="2" />
    <line x1="2" y1="10" x2="22" y2="10" />
    <line x1="2" y1="17" x2="22" y2="17" />
  </>,
  'ColumnHorizontal'
);

export const Convert = createIcon(
  <>
    <path d="M7 16V4M7 4L3 8M7 4l4 4" />
    <path d="M17 8v12M17 20l4-4M17 20l-4-4" />
  </>,
  'Convert'
);

// D
export const Data = createIcon(
  <>
    <ellipse cx="12" cy="5" rx="9" ry="3" />
    <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
    <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
  </>,
  'Data'
);

export const Delete = createIcon(
  <>
    <path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2" />
    <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6" />
    <path d="M10 11v6M14 11v6" />
  </>,
  'Delete'
);

export const Download = createIcon(
  <>
    <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
    <path d="M7 10l5 5 5-5M12 15V3" />
  </>,
  'Download'
);

// E
export const Edit = createIcon(
  <>
    <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" />
    <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" />
  </>,
  'Edit'
);

export const Extract = createIcon(
  <>
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
    <path d="M14 2v6h6" />
    <path d="M12 13v6M9 16l3 3 3-3" />
  </>,
  'Extract'
);

export const Reclamation = createIcon(
  <>
    <path d="M3 7v6h6" />
    <path d="M21 17a9 9 0 00-9-9 9 9 0 00-6 2.3L3 13" />
    <circle cx="12" cy="17" r="3" />
  </>,
  'Reclamation'
);

export const ReclamationFilled = createIcon(
  <>
    <path d="M3 7v6h6" />
    <path d="M21 17a9 9 0 00-9-9 9 9 0 00-6 2.3L3 13" />
    <circle cx="12" cy="17" r="3" fill="currentColor" stroke="none" />
  </>,
  'ReclamationFilled'
);

// F
export const File = createIcon(
  <>
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
    <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" />
  </>,
  'File'
);

export const File2 = createIcon(
  <>
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
    <path d="M14 2v6h6" />
  </>,
  'File2'
);

export const FileCheck = createIcon(
  <>
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
    <path d="M14 2v6h6" />
    <path d="M9 15l2 2 4-4" />
  </>,
  'FileCheck'
);

export const FileMultiple = createIcon(
  <>
    <path d="M15 2H8a2 2 0 00-2 2v16a2 2 0 002 2h11a2 2 0 002-2V8z" />
    <path d="M15 2v6h6" />
    <path d="M5 6H3a2 2 0 00-2 2v13a2 2 0 002 2h11" />
  </>,
  'FileMultiple'
);

export const FileSearch = createIcon(
  <>
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h7" />
    <path d="M14 2v6h6" />
    <circle cx="16.5" cy="17.5" r="2.5" />
    <path d="M21 21l-1.5-1.5" />
  </>,
  'FileSearch'
);

export const Filter = createIcon(
  <path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3z" />,
  'Filter'
);

export const Flag = createIcon(
  <>
    <path d="M5 3V21" />
    <path d="M5 4H18L15 8.5L18 13H5" />
  </>,
  'Flag'
);

export const FolderOpen = createIcon(
  <>
    <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z" />
    <line x1="2" y1="11" x2="22" y2="11" />
  </>,
  'FolderOpen'
);

export const Freeze = createIcon(
  <>
    <path d="M12 2v20M4.93 4.93l14.14 14.14M2 12h20M4.93 19.07L19.07 4.93" />
    <circle cx="12" cy="12" r="2" />
  </>,
  'Freeze'
);

// G
export const Globe = createIcon(
  <>
    <circle cx="12" cy="12" r="10" />
    <path d="M2 12h20M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z" />
  </>,
  'Globe'
);

export const Grid = createIcon(
  <>
    <rect x="3" y="3" width="7" height="7" />
    <rect x="14" y="3" width="7" height="7" />
    <rect x="14" y="14" width="7" height="7" />
    <rect x="3" y="14" width="7" height="7" />
  </>,
  'Grid'
);

// H
export const HamburgerRight = createIcon(
  <>
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <path d="M9 3v18M15 9l3 3-3 3" />
  </>,
  'HamburgerRight'
);

export const Help = createIcon(
  <>
    <circle cx="12" cy="12" r="10" />
    <path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3M12 17h.01" />
  </>,
  'Help'
);

export const Hide = createIcon(
  <>
    <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24" />
    <line x1="1" y1="1" x2="23" y2="23" />
  </>,
  'Hide'
);

export const Home = createIcon(
  <>
    <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
    <path d="M9 22V12h6v10" />
  </>,
  'Home'
);

export const HomeFilled = createIcon(
  <>
    <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" fill="currentColor" stroke="none" />
    <path d="M9 22V12h6v10" stroke="white" />
  </>,
  'HomeFilled'
);

// I
export const Info = createIcon(
  <>
    <circle cx="12" cy="12" r="10" />
    <path d="M12 16v-4M12 8h.01" />
  </>,
  'Info'
);

// L
export const Label = createIcon(
  <>
    <path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" />
    <line x1="7" y1="7" x2="7.01" y2="7" />
  </>,
  'Label'
);

export const Laptop = createIcon(
  <>
    <rect x="3" y="4" width="18" height="12" rx="2" />
    <line x1="2" y1="20" x2="22" y2="20" />
  </>,
  'Laptop'
);

export const ListNumbers = createIcon(
  <>
    <line x1="10" y1="6" x2="21" y2="6" />
    <line x1="10" y1="12" x2="21" y2="12" />
    <line x1="10" y1="18" x2="21" y2="18" />
    <path d="M4 6h1v4M4 10h2M6 18H4c0-1 2-2 2-3s-1-1.5-2-1" />
  </>,
  'ListNumbers'
);

export const Lock = createIcon(
  <>
    <rect x="3" y="11" width="18" height="11" rx="2" />
    <path d="M7 11V7a5 5 0 0110 0v4" />
  </>,
  'Lock'
);

// M
export const Mail = createIcon(
  <>
    <rect x="2" y="4" width="20" height="16" rx="2" />
    <path d="M22 6l-10 7L2 6" />
  </>,
  'Mail'
);

export const Menu = createIcon(
  <path d="M3 12h18M3 6h18M3 18h18" />,
  'Menu'
);

export const Money1 = createIcon(
  <>
    <rect x="2" y="7" width="20" height="10" rx="2" />
    <path d="M6 12h.01M18 12h.01" />
    <circle cx="12" cy="12" r="2" />
  </>,
  'Money1'
);

export const Money2 = createIcon(
  <>
    <circle cx="12" cy="12" r="10" />
    <path d="M12 6v2M12 16v2M15 9H10.5a1.5 1.5 0 000 3h3a1.5 1.5 0 010 3H9" />
  </>,
  'Money2'
);

export const Money3 = createIcon(
  <>
    <rect x="2" y="9" width="20" height="10" rx="2" />
    <path d="M6 14h.01M18 14h.01" />
    <circle cx="12" cy="14" r="2" />
    <path d="M4 7h16M6 5h12" />
  </>,
  'Money3'
);

export const Notification = createIcon(
  <>
    <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" />
  </>,
  'Notification'
);

// P
export const PieChart = createIcon(
  <>
    <path d="M21.21 15.89A10 10 0 118 2.83" />
    <path d="M22 12A10 10 0 0012 2v10z" />
  </>,
  'PieChart'
);

export const Pin = createIcon(
  <>
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
    <circle cx="12" cy="10" r="3" />
  </>,
  'Pin'
);

export const Pound = createIcon(
  <>
    <path d="M18 21H6" />
    <path d="M9 21V9.7A4 4 0 0117 8v3" />
    <path d="M7 14h8" />
  </>,
  'Pound'
);

// R
export const Receipt = createIcon(
  <>
    <path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1-2-1z" />
    <line x1="8" y1="10" x2="16" y2="10" />
    <line x1="8" y1="14" x2="12" y2="14" />
  </>,
  'Receipt'
);

export const Retry = createIcon(
  <>
    <path d="M1 4v6h6M23 20v-6h-6" />
    <path d="M20.49 9A9 9 0 005.64 5.64L1 10M23 14l-4.64 4.36A9 9 0 013.51 15" />
  </>,
  'Retry'
);

// S
export const Screen = createIcon(
  <>
    <rect x="2" y="3" width="20" height="14" rx="2" />
    <line x1="8" y1="21" x2="16" y2="21" />
    <line x1="12" y1="17" x2="12" y2="21" />
  </>,
  'Screen'
);

export const Search = createIcon(
  <>
    <circle cx="11" cy="11" r="8" />
    <path d="M21 21l-4.35-4.35" />
  </>,
  'Search'
);

export const SecuredFile = createIcon(
  <>
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
    <path d="M14 2v6h6" />
    <rect x="9" y="13" width="6" height="6" rx="1" />
    <path d="M10 13v-1.5a2 2 0 114 0V13" />
  </>,
  'SecuredFile'
);

export const Security = createIcon(
  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />,
  'Security'
);

export const Settings = createIcon(
  <>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" />
  </>,
  'Settings'
);

export const SettingsFilled = createIcon(
  <>
    <circle cx="12" cy="12" r="3" fill="currentColor" stroke="none" />
    <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" />
  </>,
  'SettingsFilled'
);

export const Show = createIcon(
  <>
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
    <circle cx="12" cy="12" r="3" />
  </>,
  'Show'
);

export const SignOut = createIcon(
  <>
    <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4" />
    <polyline points="16 17 21 12 16 7" />
    <line x1="21" y1="12" x2="9" y2="12" />
  </>,
  'SignOut'
);

export const Sort = createIcon(
  <path d="M11 5h10M11 9h7M11 13h4M3 17l4 4 4-4M7 21V3" />,
  'Sort'
);

export const Star = createIcon(
  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />,
  'Star'
);

export const StarFilled = createIcon(
  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor" stroke="none" />,
  'StarFilled'
);

export const Sync = createIcon(
  <>
    <path d="M21.5 2v6h-6M2.5 22v-6h6" />
    <path d="M2 11.5a10 10 0 0118.8-4.3M22 12.5a10 10 0 01-18.8 4.2" />
  </>,
  'Sync'
);

// U
export const Unfreeze = createIcon(
  <>
    <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
    <circle cx="12" cy="12" r="4" />
  </>,
  'Unfreeze'
);

export const Upload = createIcon(
  <>
    <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
    <path d="M17 8l-5-5-5 5M12 3v12" />
  </>,
  'Upload'
);

export const User = createIcon(
  <>
    <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
    <circle cx="12" cy="7" r="4" />
  </>,
  'User'
);

export const UserAdd = createIcon(
  <>
    <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
    <circle cx="12" cy="7" r="4" />
    <line x1="19" y1="8" x2="19" y2="14" />
    <line x1="22" y1="11" x2="16" y2="11" />
  </>,
  'UserAdd'
);

export const UserCheck = createIcon(
  <>
    <path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2" />
    <circle cx="9" cy="7" r="4" />
    <polyline points="16 11 18 13 22 9" />
  </>,
  'UserCheck'
);

export const UserSquare = createIcon(
  <>
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <circle cx="12" cy="10" r="3" />
    <path d="M7 20c0-3.31 2.24-6 5-6s5 2.69 5 6" />
  </>,
  'UserSquare'
);

export const Users = createIcon(
  <>
    <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
    <circle cx="9" cy="7" r="4" />
    <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" />
  </>,
  'Users'
);

export const UsersFilled = createIcon(
  <>
    <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" fill="currentColor" stroke="none" />
    <circle cx="9" cy="7" r="4" fill="currentColor" stroke="none" />
    <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" />
  </>,
  'UsersFilled'
);

// W
export const Wallet = createIcon(
  <>
    <path d="M21 12V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2h14a2 2 0 002-2v-5z" />
    <path d="M16 12a2 2 0 100 4h5v-4h-5z" />
  </>,
  'Wallet'
);

export const Warning = createIcon(
  <>
    <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
    <path d="M12 9v4M12 17h.01" />
  </>,
  'Warning'
);
