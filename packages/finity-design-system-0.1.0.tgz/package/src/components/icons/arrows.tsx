import { createIcon20 } from './Icon';

export const ArrowUp = createIcon20(
  <path d="M4.16536 8.88824L9.9987 3.33268M9.9987 3.33268L15.832 8.88824M9.9987 3.33268L9.9987 16.666" />,
  'ArrowUp'
);

export const ArrowDown = createIcon20(
  <path d="M15.8346 11.1118L10.0013 16.6673M10.0013 16.6673L4.16797 11.1118M10.0013 16.6673L10.0013 3.33398" />,
  'ArrowDown'
);

export const ArrowLeft = createIcon20(
  <path d="M8.89019 15.8327L3.33464 9.99935M3.33464 9.99935L8.89019 4.16602M3.33464 9.99935L16.668 9.99935" />,
  'ArrowLeft'
);

export const ArrowRight = createIcon20(
  <path d="M11.1098 4.16732L16.6654 10.0007M16.6654 10.0007L11.1098 15.834M16.6654 10.0007L3.33203 10.0006" />,
  'ArrowRight'
);

export const ArrowUpRight = createIcon20(
  <path d="M7.05026 5.90091L14.1519 5.90081M14.1519 5.90081L14.1519 12.9015M14.1519 5.90081L5.90234 14.1504" />,
  'ArrowUpRight'
);

export const ChevronUp = createIcon20(
  <path d="M5 12.33L10.335 7L15.67 12.33" />,
  'ChevronUp'
);

export const ChevronDown = createIcon20(
  <path d="M15.6667 7L10.3333 12.3333L5 7" />,
  'ChevronDown'
);

export const ChevronLeft = createIcon20(
  <path d="M12.4405 14.67L7.10547 9.335L12.4405 4" />,
  'ChevronLeft'
);

export const ChevronRight = createIcon20(
  <path d="M7.35938 4.32812L12.6944 9.66312L7.35938 14.9981" />,
  'ChevronRight'
);

export const CaretUp = createIcon20(
  <path d="M15 12.5L10 7.5L5 12.5L15 12.5Z" fill="currentColor" stroke="none" />,
  'CaretUp'
);

export const CaretDown = createIcon20(
  <path d="M5 7.5L10 12.5L15 7.5H5Z" fill="currentColor" stroke="none" />,
  'CaretDown'
);

export const CaretLeft = createIcon20(
  <path d="M12.5 5L7.5 10L12.5 15L12.5 5Z" fill="currentColor" stroke="none" />,
  'CaretLeft'
);

export const CaretRight = createIcon20(
  <path d="M7.5 15L12.5 10L7.5 5L7.5 15Z" fill="currentColor" stroke="none" />,
  'CaretRight'
);
